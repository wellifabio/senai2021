package com.wordpress.carledwinti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasytaskApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
