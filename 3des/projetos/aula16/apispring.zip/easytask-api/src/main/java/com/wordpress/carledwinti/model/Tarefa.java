package com.wordpress.carledwinti.model;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import enums.StatusTarefa;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Document
@Data
@Getter
@Setter
public class Tarefa {

		@Id
		public String id;
		public String descricao;
		public LocalDate dataCriacao;
		public LocalDate dataConclusao;
		public StatusTarefa statusTarefa;
		
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getDescricao() {
			return descricao;
		}
		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}
		public LocalDate getDataCriacao() {
			return dataCriacao;
		}
		public void setDataCriacao(LocalDate dataCriacao) {
			this.dataCriacao = dataCriacao;
		}
		public LocalDate getDataConclusao() {
			return dataConclusao;
		}
		public void setDataConclusao(LocalDate dataConclusao) {
			this.dataConclusao = dataConclusao;
		}
		public StatusTarefa getStatusTarefa() {
			return statusTarefa;
		}
		public void setStatusTarefa(StatusTarefa statusTarefa) {
			this.statusTarefa = statusTarefa;
		}
		
}
