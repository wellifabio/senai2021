package com.wordpress.carledwinti.controlller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wordpress.carledwinti.model.Tarefa;
import com.wordpress.carledwinti.repository.TarefasRepository;
import com.wordpress.carledwinti.service.TarefasService;

import enums.StatusTarefa;

@RestController
@RequestMapping("/")
public class TarefasController {
	
	@Autowired
	private TarefasService tarefaService;
	
	@GetMapping
	public String hello()
	{
		return "Bem Vindo";
	}
	
	@GetMapping("/tarefas")
	public List<Tarefa> getAll(){
		return tarefaService.findAll();
	}
	
	@PostMapping("/tarefas")
	public Tarefa create(@RequestBody Tarefa tarefa) {
		return tarefaService.save(tarefa);
	}
	
	@GetMapping("/tarefas/{id}")
	public Tarefa findById(@PathVariable String id) {
		return tarefaService.findById(id);
	}

	@GetMapping("/tarefas/descricao/{descricao}")
	public List<Tarefa> findByDescricao(@PathVariable String descricao) {
		return tarefaService.findByDescricao(descricao);
	}
	


	@PutMapping("/tarefas/{id}")
	public void update(@PathVariable String id, @RequestBody Tarefa tarefa) {
		tarefa.setId(id);
		 tarefaService.update(id,tarefa);
	}
	
	@DeleteMapping("/tarefas/{id}")
	public void delete(@PathVariable String id) {
		tarefaService.deleteById(id);
	}
}
