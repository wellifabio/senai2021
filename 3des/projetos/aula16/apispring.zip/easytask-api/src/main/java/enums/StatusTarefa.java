package enums;

import lombok.Getter;

@Getter
public enum StatusTarefa {
	A_FAZER, EM_ANDAMENTO, CONCLUIDA;
}
