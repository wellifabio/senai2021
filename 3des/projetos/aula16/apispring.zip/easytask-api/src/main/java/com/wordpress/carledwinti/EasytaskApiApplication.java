package com.wordpress.carledwinti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasytaskApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasytaskApiApplication.class, args);
	}

}
