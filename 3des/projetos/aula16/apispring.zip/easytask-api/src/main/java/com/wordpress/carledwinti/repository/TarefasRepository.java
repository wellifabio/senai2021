package com.wordpress.carledwinti.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.wordpress.carledwinti.model.Tarefa;

import enums.StatusTarefa;

@Repository
public interface TarefasRepository extends MongoRepository<Tarefa, String>{

		List<Tarefa> findByDescricaoLikeIgnoreCase(String descricao);
		List<Tarefa> findByStatusTarefaLikeIgnoreCase(StatusTarefa statusTarefa);
}
