const express = require("express");
const app = express();
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const routes = require("./routes");
const CONFIG = require("./config");

mongoose.connect(`mongodb://${CONFIG.DATABASE.URL}/${CONFIG.DATABASE.NAME}`, {
  useCreateIndex: true,
  useNewUrlParser: true
});

app.use(bodyParser.json());
app.use(cors());

app.use("/api/todo", routes.todo);

module.exports = app;
