module.exports = {
  PORT: process.env.PORT || 3000,
  DATABASE: {
    NAME: process.env.DATABASE_NAME || "dbteste",
    URL: process.env.DATABASE_URL || "localhost:27017"
  },
}
