const todoService = require("../services/todoService");

exports.get = async (req, res) => {
  const data = await todoService.list();

  res.status(200).send(data);
};

exports.getById = async (req, res) => {
  const data = await todoService.getById(req.params.id);

  res.status(data ? 200 : 404).send(data);
};

exports.post = async (req, res) => {
  const data = await todoService.create(req.body);

  res.status(200).send(data);
};

exports.put = async (req, res) => {
  const data = await todoService.update(req.params.id, req.body);

  res.status(200).send(data);
};

exports.delete = async (req, res) => {
  await todoService.delete(req.params.id);

  res.status(204).send();
};
