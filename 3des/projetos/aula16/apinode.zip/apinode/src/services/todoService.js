const Todo = require("../models/todo");

exports.list = async () => {
    return Todo.find({});
};

exports.getById = async (id) => {
    return Todo.findById(id);
};

exports.create = async (data) => {
    return Todo.create(data);
};

exports.update = async (id, data) => {
    await Todo.findByIdAndUpdate(id, data);

    return this.getById(id);
};

exports.delete = async (id) => {
    return Todo.deleteOne({ _id: id });
};